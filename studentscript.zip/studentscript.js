document.getElementById('storyModeButton').addEventListener('click', function() {
    window.location.href = 'storymode.html'; // Redirects to storymode.html
});

document.getElementById('exploreButton').addEventListener('click', function() {
    document.getElementById('selectedMode').innerText = 'You have selected Explore.';
    // You can also redirect to another page if desired
});
